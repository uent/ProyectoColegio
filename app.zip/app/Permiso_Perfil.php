<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Permiso_Perfil extends Model
{
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Controler extends Model
{
    //
}
